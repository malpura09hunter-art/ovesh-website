# Metadata Privacy Report

**Date:** 2026-11-17

## Original Files
All original JPEG files from the ZIP were inspected with ImageMagick `identify -verbose`.

Findings:
- No GPS / location coordinates present in any file.
- No detailed camera model or serial number of concern.
- Residual properties were limited to creation timestamps (from extraction) and basic JFIF data.
- Orientation tags were undefined / absent.

## Public Copies
Every publicly served image (WebP and JPEG variants) was generated with the `-strip` flag, removing residual EXIF, IPTC, and XMP metadata.

No private location data, device identifiers, or personal contact information is present in the optimized public files.

## Recommendation
Originals are retained only in the private working project (`artifacts/originals/`). Do not upload the `originals/` folder to the public website.
